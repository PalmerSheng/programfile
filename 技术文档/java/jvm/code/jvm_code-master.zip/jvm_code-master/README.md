# jvm_code
深入理解Java虚拟机：JVM高级特性与最佳实践（第2版）源代码

# 代码来源
[深入理解Java虚拟机：JVM高级特性与最佳实践（第2版）](http://www.hzbook.com/Books/7049.html)
